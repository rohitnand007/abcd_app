var jsonData = {
  "0": {
    "question": {
      "type": {
        "text": {
          "value": "building block of DNA"
        }
      }
    },
    "answer": {
      "type": {
        "text": {
          "value": "Nucleotide"
        }
      }
    }
  },
  "1": {
    "question": {
      "type": {
        "text": {
          "value": "joins nucleotides during DNA replication"
        }
      }
    },
    "answer": {
      "type": {
        "text": {
          "value": "DNA polymerase"
        }
      }
    }
  },
  "2": {
    "question": {
      "type": {
        "text": {
          "value": "molecule associated with RNA"
        }
      }
    },
    "answer": {
      "type": {
        "text": {
          "value": "Guanine"
        }
      }
    }
  },
  "3": {
    "question": {
      "type": {
        "text": {
          "value": "cytosine, guanine, adenine, and thymine"
        }
      }
    },
    "answer": {
      "type": {
        "text": {
          "value": "Bases of DNA"
        }
      }
    }
  },
  "4": {
    "question": {
      "type": {
        "text": {
          "value": "spool of protein associated with DNA"
        }
      }
    },
    "answer": {
      "type": {
        "text": {
          "value": "Histone"
        }
      }
    }
  },
  "5": {
    
  },
  "images": [
    "ignitor_logo.png"
  ],
  "name": "Cell division phases",
  "description": "Match the following phases with the proper description",
  "class": "9",
  "subject": "Biology",
  "topics": "Cell Division",
  "logo": "ignitor_logo.png",
  "instructions": "Match the following terms with their characteristics"
}
