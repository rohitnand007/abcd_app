var jsonData = {
	"finalJSON": [{
		"imageSource": "image_0937f2a0-60e7-4f89-b1be-c4b207128815",
		"itemClass": "item active"
	}, {
		"imageSource": "image_9a215c45-7ebe-4632-9b6d-f8d2816c0e9b",
		"itemClass": "item"
	}, {
		"imageSource": "image_6ee4e037-f71a-4d24-a299-485fdc34e289",
		"itemClass": "item"
	}, {
		"imageSource": "image_25fcae6d-f02e-498f-957c-ad856d991ef1",
		"itemClass": "item"
	}],
	"images": ["image_0937f2a0-60e7-4f89-b1be-c4b207128815", "image_9a215c45-7ebe-4632-9b6d-f8d2816c0e9b", "image_6ee4e037-f71a-4d24-a299-485fdc34e289", "image_25fcae6d-f02e-498f-957c-ad856d991ef1", "ignitor_logo.png"],
	"instructions": "Images for Information purposes",
	"name": "Images slideshow",
	"description": "See the Images",
	"class": "4",
	"subject": "Images",
	"topics": "Images",
	"logo": "ignitor_logo.png"
}